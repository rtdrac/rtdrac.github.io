---
title: Code
permalink: /appA/model/code/
parent: Model
grand_parent: Appendix A
nav_order: 112
---

# Code for Appendix A
