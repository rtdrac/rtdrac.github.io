---
title: Training Guide
permalink: /appA/model/training-guide/
parent: Model
grand_parent: Appendix A
nav_order: 113
---

# Training Guide for Appendix A
