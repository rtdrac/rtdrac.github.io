---
title: Model
permalink: /appA/model/
parent: Appendix A
nav_order: 110
has_children: true
---
# Model
