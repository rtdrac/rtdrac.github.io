---
title: Checkpoints
permalink: /appB/model/checkpoints/
parent: Model
grand_parent: Appendix B
nav_order: 124
---

# Checkpoints for Appendix B
