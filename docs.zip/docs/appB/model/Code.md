---
title: Code
permalink: /appB/model/code/
parent: Model
grand_parent: Appendix B
nav_order: 122
---

# Code for Appendix B
