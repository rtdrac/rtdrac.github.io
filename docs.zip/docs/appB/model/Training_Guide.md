---
title: Training Guide
permalink: /appB/model/training-guide/
parent: Model
grand_parent: Appendix B
nav_order: 123
---

# Training Guide for Appendix B
