---
title: Model
permalink: /appB/model/
parent: Appendix B
nav_order: 120
has_children: true
---
# Model
