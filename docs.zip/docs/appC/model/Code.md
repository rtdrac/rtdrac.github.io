---
title: Code
permalink: /appC/model/code/
parent: Model
grand_parent: Appendix C
nav_order: 132
---

# Code for Appendix C
