---
title: Training Guide
permalink: /appC/model/training-guide/
parent: Model
grand_parent: Appendix C
nav_order: 133
---

# Training Guide for Appendix C
