---
title: Model
permalink: /appC/model/
parent: Appendix C
nav_order: 130
has_children: true
---
# Model
