---
title: Training Guide
permalink: /appD/model/training-guide/
parent: Model
grand_parent: Appendix D
nav_order: 143
---

# Training Guide for Appendix D
