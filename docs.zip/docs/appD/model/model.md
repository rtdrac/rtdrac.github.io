---
title: Model
permalink: /appD/model/
parent: Appendix D
nav_order: 140
has_children: true
---
# Model
