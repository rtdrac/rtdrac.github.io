---
title: Chapter 3
permalink: /ch3/
nav_order: 30
has_children: true
part: "System 1"
---
# Chapter 3
