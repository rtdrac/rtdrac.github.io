---
title: Checkpoints
permalink: /ch3/model/checkpoints/
parent: Model
grand_parent: Chapter 3
nav_order: 34
---

# Checkpoints for Chapter 3
