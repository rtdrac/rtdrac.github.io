---
title: Code
permalink: /ch3/model/code/
parent: Model
grand_parent: Chapter 3
nav_order: 32
---

# Code for Chapter 3
