---
title: Overview
permalink: /ch3/model/overview/
parent: Model
grand_parent: Chapter 3
nav_order: 31
---

# Overview for Chapter 3
