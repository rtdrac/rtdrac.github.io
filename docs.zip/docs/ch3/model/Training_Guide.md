---
title: Training Guide
permalink: /ch3/model/training-guide/
parent: Model
grand_parent: Chapter 3
nav_order: 33
---

# Training Guide for Chapter 3
