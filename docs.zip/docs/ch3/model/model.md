---
title: Model
permalink: /ch3/model/
parent: Chapter 3
nav_order: 30
has_children: true
---
# Model
