---
title: Checkpoints
permalink: /ch4/model/checkpoints/
parent: Model
grand_parent: Chapter 4
nav_order: 44
---

# Checkpoints for Chapter 4
