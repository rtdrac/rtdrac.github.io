---
title: Overview
permalink: /ch4/model/overview/
parent: Model
grand_parent: Chapter 4
nav_order: 41
---

# Overview for Chapter 4
