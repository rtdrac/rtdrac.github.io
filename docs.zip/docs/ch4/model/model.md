---
title: Model
permalink: /ch4/model/
parent: Chapter 4
nav_order: 40
has_children: true
---
# Model
