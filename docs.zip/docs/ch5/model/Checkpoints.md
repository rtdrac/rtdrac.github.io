---
title: Checkpoints
permalink: /ch5/model/checkpoints/
parent: Model
grand_parent: Chapter 5
nav_order: 54
---

# Checkpoints for Chapter 5
