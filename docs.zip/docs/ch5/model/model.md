---
title: Model
permalink: /ch5/model/
parent: Chapter 5
nav_order: 50
has_children: true
---
# Model
