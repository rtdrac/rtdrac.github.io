---
title: Chapter 6
permalink: /ch6/
nav_order: 60
has_children: true
---
# Chapter 6
