---
title: Checkpoints
permalink: /ch6/model/checkpoints/
parent: Model
grand_parent: Chapter 6
nav_order: 64
---

# Checkpoints for Chapter 6
