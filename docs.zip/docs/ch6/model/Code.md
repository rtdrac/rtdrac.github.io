---
title: Code
permalink: /ch6/model/code/
parent: Model
grand_parent: Chapter 6
nav_order: 62
---

# Code for Chapter 6
