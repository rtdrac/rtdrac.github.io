---
title: Overview
permalink: /ch6/model/overview/
parent: Model
grand_parent: Chapter 6
nav_order: 61
---

# Overview for Chapter 6
