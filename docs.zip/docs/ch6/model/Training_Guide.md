---
title: Training Guide
permalink: /ch6/model/training-guide/
parent: Model
grand_parent: Chapter 6
nav_order: 63
---

# Training Guide for Chapter 6
