---
title: Model
permalink: /ch6/model/
parent: Chapter 6
nav_order: 60
has_children: true
---
# Model
