---
title: Checkpoints
permalink: /ch7/model/checkpoints/
parent: Model
grand_parent: Chapter 7
nav_order: 74
---

# Checkpoints for Chapter 7
