---
title: Code
permalink: /ch7/model/code/
parent: Model
grand_parent: Chapter 7
nav_order: 72
---

# Code for Chapter 7
