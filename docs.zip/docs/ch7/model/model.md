---
title: Model
permalink: /ch7/model/
parent: Chapter 7
nav_order: 70
has_children: true
---
# Model
