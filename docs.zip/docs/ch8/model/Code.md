---
title: Code
permalink: /ch8/model/code/
parent: Model
grand_parent: Chapter 8
nav_order: 82
---

# Code for Chapter 8
