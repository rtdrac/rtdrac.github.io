---
title: Overview
permalink: /ch8/model/overview/
parent: Model
grand_parent: Chapter 8
nav_order: 81
---

# Overview for Chapter 8
