---
title: Training Guide
permalink: /ch8/model/training-guide/
parent: Model
grand_parent: Chapter 8
nav_order: 83
---

# Training Guide for Chapter 8
