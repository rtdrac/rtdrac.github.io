---
title: Model
permalink: /ch8/model/
parent: Chapter 8
nav_order: 80
has_children: true
---
# Model
