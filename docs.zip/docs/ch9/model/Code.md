---
title: Code
permalink: /ch9/model/code/
parent: Model
grand_parent: Chapter 9
nav_order: 92
---

# Code for Chapter 9
