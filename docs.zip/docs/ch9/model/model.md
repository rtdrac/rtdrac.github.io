---
title: Model
permalink: /ch9/model/
parent: Chapter 9
nav_order: 90
has_children: true
---
# Model
